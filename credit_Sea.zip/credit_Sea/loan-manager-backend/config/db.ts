// config/db.ts
import mongoose from 'mongoose';

// Replace with your actual connection string
const mongoURI = 'mongodb://username:password@localhost:27017/loan_manager';
// Or, if using MongoDB Atlas
// const mongoURI = 'mongodb+srv://<username>:<password>@cluster0.mongodb.net/<dbname>?retryWrites=true&w=majority';

const connectDB = async () => {
    try {
        await mongoose.connect(mongoURI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('MongoDB connected');
    } catch (err) {
        console.error('MongoDB connection error:', err);
        process.exit(1); // Exit the process with failure
    }
};

export default connectDB;
