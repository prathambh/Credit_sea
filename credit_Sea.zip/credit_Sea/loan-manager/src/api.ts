import axios from 'axios';

const API_URL = 'http://localhost:5000'; // Adjust this if you're deploying the backend

export const submitLoan = async (data: any) => {
  const response = await axios.post(`${API_URL}/submit-loan`, data);
  return response.data;
};

export const getLoans = async () => {
  const response = await axios.get(`${API_URL}/loans`);
  return response.data;
};
